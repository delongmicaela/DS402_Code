
# DS402 Final Project – Early Detection of Cardiac Arrhythmia
## Micaela DeLong

This repository contains all required source code and documentation for the final DS402 project.

### Included Files
- **source_code_ds402.py** – Complete preprocessing, model training, and evaluation pipeline.
- **Source_Code_DS402.ipynb** – Notebook version of the full workflow.
- **Final_Report.pdf** – Submitted project report.
- **Updated_Proposal.docx** – Final detailed project proposal.
- **README.md** – Instructions for running the code.

### How to Run
1. Install dependencies:
```
pip install wfdb numpy pandas matplotlib scikit-learn tensorflow
```

2. Run preprocessing + training:
```
python source_code_ds402.py
```

3. To use the notebook:
Open `Source_Code_DS402.ipynb` in Google Colab or Jupyter Notebook.

Dataset will automatically download from PhysioNet if not already present.

### Notes
This project implements Logistic Regression, Random Forest, CNN, and a BiLSTM+Attention model for ECG arrhythmia detection.
